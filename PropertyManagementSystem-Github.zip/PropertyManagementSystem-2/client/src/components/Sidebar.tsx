import { Link, useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { 
  LayoutDashboard, 
  Building, 
  Users, 
  FileText, 
  Receipt, 
  Wrench, 
  CreditCard, 
  BarChart3, 
  Shield 
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Sidebar() {
  const { t } = useLanguage();
  const [location] = useLocation();

  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    select: (data: any) => data.user,
  });

  const navigation = [
    { name: t("dashboard"), href: "/", icon: LayoutDashboard },
    { name: t("properties"), href: "/properties", icon: Building },
    { name: t("tenants"), href: "/tenants", icon: Users },
    { name: t("contracts"), href: "/contracts", icon: FileText },
    { name: t("invoices"), href: "/invoices", icon: Receipt },
    { name: t("maintenance"), href: "/maintenance", icon: Wrench },
    { name: t("payments"), href: "/payments", icon: CreditCard },
    { name: t("reports"), href: "/reports", icon: BarChart3 },
  ];

  // Add admin panel if user is admin
  if (user?.role === "admin") {
    navigation.push({ name: t("admin"), href: "/admin", icon: Shield });
  }

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-gray-900">PropertyManager Pro</h1>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.name} href={item.href}>
              <a className={`nav-item ${isActive ? 'active' : ''}`}>
                <Icon className="w-5 h-5 mr-3" />
                <span>{item.name}</span>
              </a>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
