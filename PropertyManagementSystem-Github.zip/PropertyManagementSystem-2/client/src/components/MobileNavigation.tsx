import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useLanguage } from "@/hooks/useLanguage";
import { 
  Menu, 
  Home, 
  Building, 
  Users, 
  FileText, 
  Receipt, 
  Wrench, 
  CreditCard, 
  BarChart3, 
  Settings,
  LogOut
} from "lucide-react";

interface MobileNavigationProps {
  onLogout: () => void;
}

export default function MobileNavigation({ onLogout }: MobileNavigationProps) {
  const [location] = useLocation();
  const { t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const navigationItems = [
    { path: "/", icon: Home, label: t("dashboard") },
    { path: "/properties", icon: Building, label: t("properties") },
    { path: "/tenants", icon: Users, label: t("tenants") },
    { path: "/contracts", icon: FileText, label: t("contracts") },
    { path: "/invoices", icon: Receipt, label: t("invoices") },
    { path: "/maintenance", icon: Wrench, label: t("maintenance") },
    { path: "/payments", icon: CreditCard, label: t("payments") },
    { path: "/reports", icon: BarChart3, label: t("reports") },
    { path: "/admin", icon: Settings, label: t("admin") },
  ];

  const handleNavigation = () => {
    setIsOpen(false);
  };

  return (
    <div className="lg:hidden">
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="h-10 w-10">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <div className="flex flex-col h-full">
            <div className="p-6 border-b">
              <h2 className="text-lg font-semibold">Property Manager</h2>
            </div>
            <nav className="flex-1 p-4">
              <ul className="space-y-2">
                {navigationItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location === item.path;
                  
                  return (
                    <li key={item.path}>
                      <Link href={item.path}>
                        <Button
                          variant={isActive ? "secondary" : "ghost"}
                          className="w-full justify-start gap-3 h-11"
                          onClick={handleNavigation}
                        >
                          <Icon className="h-4 w-4" />
                          {item.label}
                        </Button>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </nav>
            <div className="p-4 border-t">
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 h-11 text-red-600 hover:text-red-700 hover:bg-red-50"
                onClick={() => {
                  handleNavigation();
                  onLogout();
                }}
              >
                <LogOut className="h-4 w-4" />
                {t("logout")}
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}