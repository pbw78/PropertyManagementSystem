import { Button } from "@/components/ui/button";
import { useLanguage } from "@/hooks/useLanguage";
import { Globe } from "lucide-react";

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  const languages = [
    { code: "en", name: "English", flag: "🇺🇸" },
    { code: "pl", name: "Polski", flag: "🇵🇱" },
    { code: "da", name: "Dansk", flag: "🇩🇰" },
  ];

  const currentLang = languages.find(lang => lang.code === language) || languages[0];

  const cycleLanguage = () => {
    const currentIndex = languages.findIndex(lang => lang.code === language);
    const nextIndex = (currentIndex + 1) % languages.length;
    setLanguage(languages[nextIndex].code);
  };

  return (
    <Button 
      variant="ghost" 
      size="sm" 
      onClick={cycleLanguage}
      className="flex items-center gap-2 h-8 px-2"
    >
      <Globe className="h-4 w-4" />
      <span className="hidden sm:inline">{currentLang.name}</span>
      <span className="sm:hidden">{currentLang.flag}</span>
    </Button>
  );
}