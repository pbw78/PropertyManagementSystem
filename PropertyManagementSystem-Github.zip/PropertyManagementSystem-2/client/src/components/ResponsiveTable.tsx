import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface ResponsiveTableProps {
  headers: string[];
  children: ReactNode;
  className?: string;
}

export function ResponsiveTable({ headers, children, className = "" }: ResponsiveTableProps) {
  return (
    <div className={`${className}`}>
      {/* Desktop Table */}
      <div className="hidden md:block">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {headers.map((header, index) => (
                  <th
                    key={index}
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {children}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden space-y-4">
        {children}
      </div>
    </div>
  );
}

interface ResponsiveRowProps {
  children: ReactNode;
  mobileCard?: ReactNode;
}

export function ResponsiveRow({ children, mobileCard }: ResponsiveRowProps) {
  return (
    <>
      {/* Desktop Row */}
      <tr className="hidden md:table-row hover:bg-gray-50">
        {children}
      </tr>
      
      {/* Mobile Card */}
      <div className="md:hidden">
        {mobileCard || (
          <Card>
            <CardContent className="p-4">
              {children}
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}

interface ResponsiveCellProps {
  children: ReactNode;
  className?: string;
}

export function ResponsiveCell({ children, className = "" }: ResponsiveCellProps) {
  return (
    <td className={`px-6 py-4 whitespace-nowrap ${className}`}>
      {children}
    </td>
  );
}