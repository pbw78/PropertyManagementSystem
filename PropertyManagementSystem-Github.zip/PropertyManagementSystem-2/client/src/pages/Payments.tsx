import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, CheckCircle, Clock, AlertTriangle } from "lucide-react";
import RecordPaymentModal from "@/components/modals/RecordPaymentModal";
import { format } from "date-fns";

export default function Payments() {
  const { t } = useLanguage();
  const [showRecordModal, setShowRecordModal] = useState(false);

  const { data: payments = [], isLoading } = useQuery({
    queryKey: ["/api/payments"],
  });

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      completed: { variant: "secondary" as const, text: t("completed"), icon: CheckCircle },
      pending: { variant: "outline" as const, text: t("pending"), icon: Clock },
      failed: { variant: "destructive" as const, text: "Failed", icon: AlertTriangle },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    const Icon = config.icon;
    return (
      <Badge variant={config.variant} className="flex items-center space-x-1">
        <Icon className="h-3 w-3" />
        <span>{config.text}</span>
      </Badge>
    );
  };

  const getMethodText = (method: string) => {
    const methodMap = {
      bank_transfer: t("bank_transfer"),
      check: t("check"),
      cash: t("cash"),
      online: t("online"),
    };
    return methodMap[method as keyof typeof methodMap] || method;
  };

  // Calculate summary stats
  const collectedThisMonth = payments
    .filter((payment: any) => {
      const paymentDate = new Date(payment.paymentDate);
      const currentMonth = new Date();
      return paymentDate.getMonth() === currentMonth.getMonth() && 
             paymentDate.getFullYear() === currentMonth.getFullYear() &&
             payment.status === "completed";
    })
    .reduce((sum: number, payment: any) => sum + parseFloat(payment.amount), 0);

  const pendingPayments = payments
    .filter((payment: any) => payment.status === "pending")
    .reduce((sum: number, payment: any) => sum + parseFloat(payment.amount), 0);

  const failedPayments = payments
    .filter((payment: any) => payment.status === "failed")
    .reduce((sum: number, payment: any) => sum + parseFloat(payment.amount), 0);

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-300 rounded w-1/4 mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-300 rounded"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-300 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">{t("payments")}</h2>
          <p className="text-gray-600">{t("payments_subtitle")}</p>
        </div>
        <Button onClick={() => setShowRecordModal(true)}>
          <Plus className="h-4 w-4 mr-2" />
          {t("record_payment")}
        </Button>
      </div>

      {/* Payment Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="stats-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{t("collected_this_month")}</p>
                <p className="text-2xl font-bold text-green-600">${collectedThisMonth.toFixed(2)}</p>
              </div>
              <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="text-green-600 text-xl" size={24} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="stats-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{t("pending_payments")}</p>
                <p className="text-2xl font-bold text-yellow-600">${pendingPayments.toFixed(2)}</p>
              </div>
              <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="text-yellow-600 text-xl" size={24} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="stats-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Failed Payments</p>
                <p className="text-2xl font-bold text-red-600">${failedPayments.toFixed(2)}</p>
              </div>
              <div className="h-12 w-12 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertTriangle className="text-red-600 text-xl" size={24} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payments Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("date")}</TableHead>
                <TableHead>{t("tenant")}</TableHead>
                <TableHead>{t("property")}</TableHead>
                <TableHead>{t("amount")}</TableHead>
                <TableHead>{t("method")}</TableHead>
                <TableHead>{t("status")}</TableHead>
                <TableHead>{t("reference")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payments.map((payment: any) => (
                <TableRow key={payment.id} className="hover:bg-gray-50">
                  <TableCell>
                    {format(new Date(payment.paymentDate), "MMM dd, yyyy")}
                  </TableCell>
                  <TableCell>
                    {payment.invoice?.contract?.tenant ? 
                      `${payment.invoice.contract.tenant.firstName} ${payment.invoice.contract.tenant.lastName}` :
                      "Unknown"
                    }
                  </TableCell>
                  <TableCell>
                    {payment.invoice?.contract?.property?.name || "Unknown"}
                  </TableCell>
                  <TableCell className="font-medium">
                    ${payment.amount}
                  </TableCell>
                  <TableCell>
                    {getMethodText(payment.paymentMethod)}
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(payment.status)}
                  </TableCell>
                  <TableCell className="text-gray-500">
                    {payment.reference || "-"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {payments.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No payments found</p>
            </div>
          )}
        </CardContent>
      </Card>

      <RecordPaymentModal 
        open={showRecordModal} 
        onClose={() => setShowRecordModal(false)} 
      />
    </div>
  );
}
