import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Settings2, AlertTriangle } from "lucide-react";
import AddMaintenanceModal from "@/components/modals/AddMaintenanceModal";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function Maintenance() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAddModal, setShowAddModal] = useState(false);

  const { data: maintenanceRequests = [], isLoading } = useQuery({
    queryKey: ["/api/maintenance"],
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => 
      apiRequest("PUT", `/api/maintenance/${id}`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/maintenance"] });
      toast({
        title: t("success"),
        description: "Maintenance request updated successfully",
      });
    },
    onError: () => {
      toast({
        title: t("error"),
        description: "Failed to update maintenance request",
        variant: "destructive",
      });
    },
  });

  const getPriorityBadge = (priority: string) => {
    const priorityConfig = {
      low: { variant: "secondary" as const, text: t("low"), className: "priority-badge-low" },
      medium: { variant: "outline" as const, text: t("medium"), className: "priority-badge-medium" },
      high: { variant: "destructive" as const, text: t("high"), className: "priority-badge-high" },
      urgent: { variant: "destructive" as const, text: t("urgent"), className: "priority-badge-urgent" },
    };
    
    const config = priorityConfig[priority as keyof typeof priorityConfig] || priorityConfig.medium;
    return <Badge variant={config.variant} className={config.className}>{config.text}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { variant: "outline" as const, text: t("pending") },
      in_progress: { variant: "outline" as const, text: "In Progress" },
      completed: { variant: "secondary" as const, text: t("completed") },
      cancelled: { variant: "destructive" as const, text: "Cancelled" },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return <Badge variant={config.variant}>{config.text}</Badge>;
  };

  const getPriorityIcon = (priority: string) => {
    if (priority === "urgent" || priority === "high") {
      return <AlertTriangle className="h-5 w-5 text-red-500" />;
    }
    return <Settings2 className="h-5 w-5 text-blue-500" />;
  };

  const handleUpdateStatus = (id: number, status: string) => {
    updateStatusMutation.mutate({ id, status });
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-300 rounded w-1/4 mb-8"></div>
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-300 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">{t("maintenance")}</h2>
          <p className="text-gray-600">{t("maintenance_subtitle")}</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <Plus className="h-4 w-4 mr-2" />
          {t("new_request")}
        </Button>
      </div>

      <div className="space-y-6">
        {maintenanceRequests.map((request: any) => (
          <Card key={request.id}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-start space-x-4">
                  <div className="h-12 w-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    {getPriorityIcon(request.priority)}
                  </div>
                  <div>
                    <CardTitle className="text-lg mb-1">{request.title}</CardTitle>
                    <p className="text-gray-600 mb-2">{request.description}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>
                        📍 {request.property?.name || "Unknown Property"}
                      </span>
                      {request.tenant && (
                        <span>
                          👤 {request.tenant.firstName} {request.tenant.lastName}
                        </span>
                      )}
                      <span>
                        📅 {format(new Date(request.createdAt), "MMM dd, yyyy")}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {getPriorityBadge(request.priority)}
                  {getStatusBadge(request.status)}
                </div>
              </div>
              
              <div className="flex justify-between items-center pt-4 border-t border-gray-200">
                <div className="text-sm text-gray-600">
                  <span className="font-medium">{t("estimated_cost")}:</span> 
                  {request.estimatedCost ? ` $${request.estimatedCost}` : " Not specified"}
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleUpdateStatus(request.id, "in_progress")}
                    disabled={updateStatusMutation.isPending || request.status === "completed"}
                  >
                    {t("update_status")}
                  </Button>
                  <Button variant="outline" size="sm">
                    {t("view_details")}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {maintenanceRequests.length === 0 && (
        <div className="text-center py-12">
          <Settings2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No maintenance requests found</p>
        </div>
      )}

      <AddMaintenanceModal 
        open={showAddModal} 
        onClose={() => setShowAddModal(false)} 
      />
    </div>
  );
}
