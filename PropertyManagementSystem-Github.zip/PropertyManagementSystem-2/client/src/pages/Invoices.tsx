import { useLanguage } from "@/hooks/useLanguage";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Download, Mail, Printer, FileSpreadsheet } from "lucide-react";
import { exportToExcel } from "@/lib/exportUtils";
import { format } from "date-fns";

export default function Invoices() {
  const { t } = useLanguage();

  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ["/api/invoices"],
  });

  const handleExportExcel = () => {
    const data = invoices.map((invoice: any) => ({
      "Invoice Number": invoice.invoiceNumber,
      "Tenant": `${invoice.contract.tenant.firstName} ${invoice.contract.tenant.lastName}`,
      "Property": invoice.contract.property.name,
      "Amount": `$${invoice.amount}`,
      "Due Date": format(new Date(invoice.dueDate), "yyyy-MM-dd"),
      "Status": invoice.status,
    }));
    
    exportToExcel(data, "invoices");
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      paid: { variant: "secondary" as const, text: t("paid") },
      pending: { variant: "outline" as const, text: t("pending") },
      overdue: { variant: "destructive" as const, text: t("overdue") },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return <Badge variant={config.variant}>{config.text}</Badge>;
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-300 rounded w-1/4 mb-8"></div>
          <div className="h-64 bg-gray-300 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">{t("invoices")}</h2>
          <p className="text-gray-600">{t("invoices_subtitle")}</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" onClick={handleExportExcel}>
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            {t("export_excel")}
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            {t("create_invoice")}
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("invoice_number")}</TableHead>
                <TableHead>{t("tenant")}</TableHead>
                <TableHead>{t("property")}</TableHead>
                <TableHead>{t("amount")}</TableHead>
                <TableHead>{t("due_date")}</TableHead>
                <TableHead>{t("status")}</TableHead>
                <TableHead>{t("actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map((invoice: any) => (
                <TableRow key={invoice.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium text-primary">
                    {invoice.invoiceNumber}
                  </TableCell>
                  <TableCell>
                    {invoice.contract.tenant.firstName} {invoice.contract.tenant.lastName}
                  </TableCell>
                  <TableCell>{invoice.contract.property.name}</TableCell>
                  <TableCell className="font-medium">
                    ${invoice.amount}
                  </TableCell>
                  <TableCell>
                    {format(new Date(invoice.dueDate), "yyyy-MM-dd")}
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(invoice.status)}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Mail className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Printer className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {invoices.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No invoices found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
