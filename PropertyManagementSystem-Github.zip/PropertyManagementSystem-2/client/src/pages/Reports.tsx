import { useLanguage } from "@/hooks/useLanguage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileDown, FileSpreadsheet, FileText } from "lucide-react";
import { exportToExcel } from "@/lib/exportUtils";
import { useQuery } from "@tanstack/react-query";

export default function Reports() {
  const { t } = useLanguage();

  const { data: properties = [] } = useQuery({
    queryKey: ["/api/properties"],
  });

  const { data: contracts = [] } = useQuery({
    queryKey: ["/api/contracts"],
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["/api/payments"],
  });

  const { data: maintenanceRequests = [] } = useQuery({
    queryKey: ["/api/maintenance"],
  });

  const handleExportProperties = () => {
    const data = properties.map((property: any) => ({
      "Property Name": property.name,
      "Address": property.address,
      "Type": property.propertyType,
      "Bedrooms": property.bedrooms,
      "Bathrooms": property.bathrooms,
      "Monthly Rent": `$${property.monthlyRent}`,
      "Status": property.status,
    }));
    
    exportToExcel(data, "properties_report");
  };

  const handleExportContracts = () => {
    const data = contracts.map((contract: any) => ({
      "Tenant": `${contract.tenant.firstName} ${contract.tenant.lastName}`,
      "Property": contract.property.name,
      "Start Date": contract.startDate,
      "End Date": contract.endDate,
      "Monthly Rent": `$${contract.monthlyRent}`,
      "Status": contract.status,
    }));
    
    exportToExcel(data, "contracts_report");
  };

  const handleExportFinancial = () => {
    const data = payments.map((payment: any) => ({
      "Date": payment.paymentDate,
      "Tenant": payment.invoice?.contract?.tenant ? 
        `${payment.invoice.contract.tenant.firstName} ${payment.invoice.contract.tenant.lastName}` : 
        "Unknown",
      "Property": payment.invoice?.contract?.property?.name || "Unknown",
      "Amount": `$${payment.amount}`,
      "Method": payment.paymentMethod,
      "Status": payment.status,
      "Reference": payment.reference || "",
    }));
    
    exportToExcel(data, "financial_report");
  };

  const handleExportMaintenance = () => {
    const data = maintenanceRequests.map((request: any) => ({
      "Title": request.title,
      "Property": request.property?.name || "Unknown",
      "Priority": request.priority,
      "Status": request.status,
      "Estimated Cost": request.estimatedCost ? `$${request.estimatedCost}` : "Not specified",
      "Created Date": request.createdAt,
    }));
    
    exportToExcel(data, "maintenance_report");
  };

  // Calculate some basic stats for the overview
  const totalRevenue = payments
    .filter((payment: any) => payment.status === "completed")
    .reduce((sum: number, payment: any) => sum + parseFloat(payment.amount), 0);

  const occupancyRate = properties.length > 0 ? 
    ((properties.filter((p: any) => p.status === "rented").length / properties.length) * 100).toFixed(1) : 0;

  const pendingMaintenance = maintenanceRequests.filter((r: any) => r.status === "pending").length;

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">{t("reports")}</h2>
        <p className="text-gray-600">{t("reports_subtitle")}</p>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="stats-card">
          <CardContent className="p-6">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-3xl font-bold text-gray-900">${totalRevenue.toFixed(2)}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="stats-card">
          <CardContent className="p-6">
            <div>
              <p className="text-sm font-medium text-gray-600">{t("occupancy_rate")}</p>
              <p className="text-3xl font-bold text-gray-900">{occupancyRate}%</p>
            </div>
          </CardContent>
        </Card>

        <Card className="stats-card">
          <CardContent className="p-6">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending Maintenance</p>
              <p className="text-3xl font-bold text-gray-900">{pendingMaintenance}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Filters */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Generate Custom Report</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
              <Select defaultValue="last_30_days">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last_30_days">Last 30 days</SelectItem>
                  <SelectItem value="last_3_months">Last 3 months</SelectItem>
                  <SelectItem value="last_6_months">Last 6 months</SelectItem>
                  <SelectItem value="last_year">Last year</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">{t("property_type")}</label>
              <Select defaultValue="all">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Properties</SelectItem>
                  <SelectItem value="apartment">{t("apartment")}</SelectItem>
                  <SelectItem value="house">{t("house")}</SelectItem>
                  <SelectItem value="commercial">{t("commercial")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
              <Select defaultValue="financial">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="financial">Financial Summary</SelectItem>
                  <SelectItem value="occupancy">Occupancy Rate</SelectItem>
                  <SelectItem value="maintenance">Maintenance Costs</SelectItem>
                  <SelectItem value="tenant">Tenant Activity</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button className="w-full">
                <FileText className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Export Options */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Export Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button variant="outline" onClick={handleExportProperties} className="h-20 flex flex-col">
              <FileSpreadsheet className="h-6 w-6 mb-2 text-green-600" />
              <span>Properties Report</span>
            </Button>
            
            <Button variant="outline" onClick={handleExportContracts} className="h-20 flex flex-col">
              <FileText className="h-6 w-6 mb-2 text-blue-600" />
              <span>Contracts Report</span>
            </Button>
            
            <Button variant="outline" onClick={handleExportFinancial} className="h-20 flex flex-col">
              <FileDown className="h-6 w-6 mb-2 text-yellow-600" />
              <span>Financial Report</span>
            </Button>
            
            <Button variant="outline" onClick={handleExportMaintenance} className="h-20 flex flex-col">
              <FileSpreadsheet className="h-6 w-6 mb-2 text-purple-600" />
              <span>Maintenance Report</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
