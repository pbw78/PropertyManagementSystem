import { useLanguage } from "@/hooks/useLanguage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Building, Users, DollarSign, Wrench, Plus, UserPlus, Receipt, Settings } from "lucide-react";
import { useState } from "react";
import AddPropertyModal from "@/components/modals/AddPropertyModal";
import AddTenantModal from "@/components/modals/AddTenantModal";

export default function Dashboard() {
  const { t } = useLanguage();
  const [showAddProperty, setShowAddProperty] = useState(false);
  const [showAddTenant, setShowAddTenant] = useState(false);

  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-300 rounded w-1/4 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-300 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const statsCards = [
    {
      title: t("total_properties"),
      value: stats?.totalProperties || 0,
      icon: Building,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: t("active_tenants"),
      value: stats?.activeTenants || 0,
      icon: Users,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: t("monthly_revenue"),
      value: `$${stats?.monthlyRevenue || 0}`,
      icon: DollarSign,
      color: "text-yellow-600",
      bgColor: "bg-yellow-100",
    },
    {
      title: t("maintenance_requests"),
      value: stats?.pendingMaintenance || 0,
      icon: Wrench,
      color: "text-red-600",
      bgColor: "bg-red-100",
    },
  ];

  const quickActions = [
    {
      title: t("add_property"),
      icon: Plus,
      color: "text-blue-600",
      onClick: () => setShowAddProperty(true),
    },
    {
      title: t("add_tenant"),
      icon: UserPlus,
      color: "text-green-600",
      onClick: () => setShowAddTenant(true),
    },
    {
      title: t("create_invoice"),
      icon: Receipt,
      color: "text-yellow-600",
      onClick: () => console.log("Create invoice"),
    },
    {
      title: t("maintenance_request"),
      icon: Settings,
      color: "text-purple-600",
      onClick: () => console.log("Maintenance request"),
    },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">{t("dashboard")}</h2>
        <p className="text-gray-600">{t("dashboard_subtitle")}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statsCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <Card key={index} className="stats-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{card.title}</p>
                    <p className="text-3xl font-bold text-gray-900">{card.value}</p>
                  </div>
                  <div className={`h-12 w-12 ${card.bgColor} rounded-lg flex items-center justify-center`}>
                    <Icon className={`${card.color} text-xl`} size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>{t("quick_actions")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Button
                    key={index}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2"
                    onClick={action.onClick}
                  >
                    <Icon className={action.color} size={24} />
                    <span className="text-sm font-medium">{action.title}</span>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t("recent_activity")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center text-gray-500 py-8">
                No recent activity
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modals */}
      <AddPropertyModal 
        open={showAddProperty} 
        onClose={() => setShowAddProperty(false)} 
      />
      <AddTenantModal 
        open={showAddTenant} 
        onClose={() => setShowAddTenant(false)} 
      />
    </div>
  );
}
