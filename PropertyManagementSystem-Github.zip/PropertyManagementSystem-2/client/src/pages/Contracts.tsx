import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Download, Edit, Ban } from "lucide-react";
import AddContractModal from "@/components/modals/AddContractModal";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function Contracts() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAddModal, setShowAddModal] = useState(false);

  const { data: contracts = [], isLoading } = useQuery({
    queryKey: ["/api/contracts"],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/contracts/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      toast({
        title: t("success"),
        description: "Contract terminated successfully",
      });
    },
    onError: () => {
      toast({
        title: t("error"),
        description: "Failed to terminate contract",
        variant: "destructive",
      });
    },
  });

  const handleTerminate = (id: number) => {
    if (window.confirm("Are you sure you want to terminate this contract?")) {
      deleteMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-300 rounded w-1/4 mb-8"></div>
          <div className="h-64 bg-gray-300 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">{t("contracts")}</h2>
          <p className="text-gray-600">{t("contracts_subtitle")}</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <Plus className="h-4 w-4 mr-2" />
          {t("new_contract")}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("tenant")}</TableHead>
                <TableHead>{t("property")}</TableHead>
                <TableHead>{t("start_date")}</TableHead>
                <TableHead>{t("end_date")}</TableHead>
                <TableHead>{t("rent")}</TableHead>
                <TableHead>{t("status")}</TableHead>
                <TableHead>{t("actions")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contracts.map((contract: any) => (
                <TableRow key={contract.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">
                    {contract.tenant.firstName} {contract.tenant.lastName}
                  </TableCell>
                  <TableCell>{contract.property.name}</TableCell>
                  <TableCell>
                    {format(new Date(contract.startDate), "yyyy-MM-dd")}
                  </TableCell>
                  <TableCell>
                    {format(new Date(contract.endDate), "yyyy-MM-dd")}
                  </TableCell>
                  <TableCell className="font-medium">
                    ${contract.monthlyRent}
                  </TableCell>
                  <TableCell>
                    <Badge variant={contract.status === "active" ? "secondary" : "outline"}>
                      {t(contract.status)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleTerminate(contract.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Ban className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {contracts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No contracts found</p>
            </div>
          )}
        </CardContent>
      </Card>

      <AddContractModal 
        open={showAddModal} 
        onClose={() => setShowAddModal(false)} 
      />
    </div>
  );
}
