export const translations = {
  en: {
    flag: "🇺🇸",
    name: "English"
  },
  pl: {
    flag: "🇵🇱",
    name: "Polski"
  },
  da: {
    flag: "🇩🇰",
    name: "Dansk"
  }
};
