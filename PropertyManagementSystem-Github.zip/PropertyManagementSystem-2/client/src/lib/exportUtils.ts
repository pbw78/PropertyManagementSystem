export const exportToExcel = (data: any[], filename: string) => {
  if (data.length === 0) {
    alert("No data to export");
    return;
  }

  // Convert data to CSV format
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(","),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header];
        // Handle values that contain commas or quotes
        if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      }).join(",")
    )
  ].join("\n");

  // Create and download the file
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

export const exportToPDF = async (data: any[], filename: string, title?: string) => {
  // This is a placeholder for PDF export functionality
  // In a real application, you would use a library like jsPDF or similar
  console.log("PDF export not yet implemented", { data, filename, title });
  alert("PDF export functionality is not yet implemented. Use CSV export instead.");
};

export const generateInvoicePDF = async (invoice: any) => {
  // This is a placeholder for invoice PDF generation
  // In a real application, you would use a library like jsPDF with custom formatting
  console.log("Invoice PDF generation not yet implemented", invoice);
  alert("Invoice PDF generation is not yet implemented.");
};

export const generateContractPDF = async (contract: any) => {
  // This is a placeholder for contract PDF generation
  // In a real application, you would use a library like jsPDF with custom formatting
  console.log("Contract PDF generation not yet implemented", contract);
  alert("Contract PDF generation is not yet implemented.");
};

export const exportTableToCSV = (tableId: string, filename: string) => {
  const table = document.getElementById(tableId);
  if (!table) {
    alert("Table not found");
    return;
  }

  let csv = "";
  const rows = table.querySelectorAll("tr");
  
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const cols = row.querySelectorAll("td, th");
    const csvRow = [];
    
    for (let j = 0; j < cols.length; j++) {
      let cellText = cols[j].textContent || "";
      cellText = cellText.replace(/"/g, '""'); // Escape quotes
      csvRow.push(`"${cellText}"`);
    }
    
    csv += csvRow.join(",") + "\n";
  }

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};
