import { apiRequest } from "./queryClient";

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  role: string;
}

export interface AuthResponse {
  user: User;
}

export const authService = {
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const response = await apiRequest("POST", "/api/auth/login", credentials);
    return await response.json();
  },

  async logout(): Promise<void> {
    await apiRequest("POST", "/api/auth/logout");
  },

  async getCurrentUser(): Promise<AuthResponse> {
    const response = await apiRequest("GET", "/api/auth/me");
    return await response.json();
  },

  async refreshAuth(): Promise<boolean> {
    try {
      await this.getCurrentUser();
      return true;
    } catch (error) {
      return false;
    }
  },
};

export const isAuthenticated = async (): Promise<boolean> => {
  try {
    await authService.getCurrentUser();
    return true;
  } catch (error) {
    return false;
  }
};

export const getStoredUser = (): User | null => {
  const stored = localStorage.getItem("user");
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (error) {
      localStorage.removeItem("user");
    }
  }
  return null;
};

export const setStoredUser = (user: User): void => {
  localStorage.setItem("user", JSON.stringify(user));
};

export const removeStoredUser = (): void => {
  localStorage.removeItem("user");
};
